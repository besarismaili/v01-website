const { useState, useEffect, useMemo, useRef } = React;

// ---------- icons ----------
const Icon = {
  search: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>,
  plus: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M12 5v14M5 12h14"/></svg>,
  pencil: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M16 4l4 4-12 12H4v-4z"/></svg>,
  trash: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>,
  copy: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="8" y="8" width="12" height="12"/><path d="M16 8V4H4v12h4"/></svg>,
  eye: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>,
  close: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M5 5l14 14M19 5L5 19"/></svg>,
  check: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="M5 12l5 5 9-11"/></svg>,
  filter: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M3 5h18l-7 9v6l-4-2v-4z"/></svg>,
  list: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M3 6h18M3 12h18M3 18h18"/></svg>,
  grid: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>,
  star: <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3l3 6 6 1-4.5 4.5L18 21l-6-3-6 3 1.5-6.5L3 10l6-1z"/></svg>,
  arrow: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M5 12h14M14 5l7 7-7 7"/></svg>,
};

// ---------- seed data ----------
const SEED = [
  { id:'p1',  title:'Echoes of Tomorrow', client:'Atlas Pictures',  category:'Brand Film',     year:2026, runtime:'04:32', status:'Published', featured:true,  director:'Mara Voss',     vfxSup:'Idris Khoury',  shots:214, updated:'Apr 24, 2026', tags:['hero','virtual-stage','hdr'], summary:'An immersive brand film exploring the architecture of memory.' },
  { id:'p2',  title:'Dusk',                client:'Halflight Records', category:'Music Video',  year:2026, runtime:'03:48', status:'Published', featured:false, director:'Jin Reyes',     vfxSup:'Idris Khoury',  shots:96,  updated:'Apr 18, 2026', tags:['portrait','low-light'], summary:'Portrait-driven music video for Halflight Records.' },
  { id:'p3',  title:'The Light Between',   client:'Pearl & Wave',      category:'Short Film',    year:2026, runtime:'12:48', status:'Published', featured:false, director:'Sofia Marin',   vfxSup:'Theo Park',     shots:182, updated:'Apr 11, 2026', tags:['festival','seascape'], summary:'A father, a daughter, and the lighthouse between them.' },
  { id:'p4',  title:'Outpost 7',           client:'Northbound',        category:'VFX / Post',    year:2026, runtime:'02:30', status:'Draft',     featured:false, director:'Mara Voss',     vfxSup:'Idris Khoury',  shots:64,  updated:'Apr 30, 2026', tags:['sci-fi','spacesuit'], summary:'Compositing-heavy VFX delivery for streaming spot.' },
  { id:'p5',  title:'Signal Lost',         client:'Atlas Pictures',    category:'Brand Film',    year:2025, runtime:'01:30', status:'Published', featured:false, director:'Mara Voss',     vfxSup:'Idris Khoury',  shots:48,  updated:'Dec 12, 2025', tags:['vertical-light'], summary:'Brand spot — light from above, hope from below.' },
  { id:'p6',  title:'Carrier-9',           client:'Northbound',        category:'Commercial',    year:2025, runtime:'01:00', status:'Published', featured:false, director:'Theo Park',     vfxSup:'Theo Park',     shots:32,  updated:'Nov 04, 2025', tags:['vehicle','night'], summary:'Hero vehicle commercial with full virtual stage.' },
  { id:'p7',  title:'Halflight',           client:'Halflight Records', category:'Music Video',  year:2025, runtime:'04:01', status:'Published', featured:false, director:'Jin Reyes',     vfxSup:'Theo Park',     shots:88,  updated:'Sep 22, 2025', tags:['rain','close-up'], summary:'Rain-soaked second single from the Halflight EP.' },
  { id:'p8',  title:'Solar Field',         client:'Verdant Energy',    category:'Commercial',    year:2025, runtime:'00:60', status:'Archived',  featured:false, director:'Sofia Marin',   vfxSup:'Theo Park',     shots:24,  updated:'Aug 11, 2025', tags:['eclipse','outdoor'], summary:'Eclipse-coded brand spot for clean energy launch.' },
  { id:'p9',  title:'Salt & Static',       client:'Independent',       category:'Short Film',    year:2024, runtime:'09:12', status:'Published', featured:false, director:'Sofia Marin',   vfxSup:'Idris Khoury',  shots:142, updated:'Jun 02, 2024', tags:['desert','figure'], summary:'Festival-circuit short, desert-set, dialogue-light.' },
  { id:'p10', title:'Room 24',             client:'Halflight Records', category:'Music Video',  year:2024, runtime:'03:14', status:'Archived',  featured:false, director:'Jin Reyes',     vfxSup:'Theo Park',     shots:54,  updated:'Mar 18, 2024', tags:['interior','warm'], summary:'Interior-lit music video, single-take pacing.' },
  { id:'p11', title:'Northbound',          client:'Northbound',        category:'Brand Film',    year:2026, runtime:'02:14', status:'Scheduled', featured:false, director:'Mara Voss',     vfxSup:'Idris Khoury',  shots:74,  updated:'May 02, 2026', tags:['origin-film','hero'], summary:'Origin film for the Northbound spring campaign.' },
  { id:'p12', title:'Glass Coast',         client:'Pearl & Wave',      category:'Commercial',    year:2026, runtime:'00:45', status:'Draft',     featured:false, director:'Theo Park',     vfxSup:'Theo Park',     shots:22,  updated:'May 04, 2026', tags:['ocean','brand'], summary:'Beverage brand commercial, oceanic mood film.' },
];

const CATEGORIES = ['Brand Film','Commercial','Music Video','Short Film','VFX / Post'];
const STATUSES   = ['Published','Draft','Scheduled','Archived'];
const DIRECTORS  = ['Mara Voss','Jin Reyes','Sofia Marin','Theo Park'];
const SUPES      = ['Idris Khoury','Theo Park','Lena Ortiz','Owen Vasquez'];

// ---------- main app ----------
function App(){
  const [items, setItems]       = useState(SEED);
  const [query, setQuery]       = useState('');
  const [filterCat, setFilterCat]       = useState(new Set());
  const [filterStatus, setFilterStatus] = useState(new Set());
  const [showFilterCat, setShowFilterCat]       = useState(false);
  const [showFilterStatus, setShowFilterStatus] = useState(false);
  const [view, setView]         = useState('list'); // 'list' | 'grid'
  const [sortBy, setSortBy]     = useState({ key:'updated', dir:'desc' });
  const [selected, setSelected] = useState(new Set());
  const [drawer, setDrawer]     = useState(null); // { mode:'edit'|'new', item }
  const [confirm, setConfirm]   = useState(null); // { ids, multiple }
  const [toast, setToast]       = useState(null);
  const [page, setPage]         = useState(1);
  const PER_PAGE = 8;

  // close popovers on outside click
  useEffect(() => {
    const handler = (e) => {
      if (!e.target.closest('.filter-wrap')) {
        setShowFilterCat(false);
        setShowFilterStatus(false);
      }
    };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  // toast auto-dismiss
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(t);
  }, [toast]);

  const filtered = useMemo(() => {
    let arr = items.slice();
    if (query.trim()){
      const q = query.toLowerCase();
      arr = arr.filter(p => p.title.toLowerCase().includes(q) || p.client.toLowerCase().includes(q) || p.director.toLowerCase().includes(q) || p.tags.some(t => t.includes(q)));
    }
    if (filterCat.size)    arr = arr.filter(p => filterCat.has(p.category));
    if (filterStatus.size) arr = arr.filter(p => filterStatus.has(p.status));
    arr.sort((a,b) => {
      const k = sortBy.key, d = sortBy.dir === 'asc' ? 1 : -1;
      if (k === 'updated'){ return d * (new Date(a.updated) - new Date(b.updated)); }
      if (typeof a[k] === 'number') return d * (a[k] - b[k]);
      return d * String(a[k]).localeCompare(String(b[k]));
    });
    return arr;
  }, [items, query, filterCat, filterStatus, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const pageItems  = filtered.slice((page-1)*PER_PAGE, page*PER_PAGE);
  useEffect(() => { if (page > totalPages) setPage(1); }, [filtered.length, totalPages]);

  const stats = useMemo(() => ({
    total:     items.length,
    published: items.filter(p => p.status === 'Published').length,
    drafts:    items.filter(p => p.status === 'Draft').length,
    featured:  items.filter(p => p.featured).length,
    shots:     items.reduce((a,p) => a + p.shots, 0),
  }), [items]);

  const toggleSelect = (id) => {
    const next = new Set(selected);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelected(next);
  };
  const toggleSelectAll = () => {
    const allOnPage = pageItems.every(p => selected.has(p.id));
    const next = new Set(selected);
    pageItems.forEach(p => allOnPage ? next.delete(p.id) : next.add(p.id));
    setSelected(next);
  };
  const toggleFilter = (set, val, setter) => {
    const next = new Set(set);
    next.has(val) ? next.delete(val) : next.add(val);
    setter(next);
  };
  const clearFilters = () => { setQuery(''); setFilterCat(new Set()); setFilterStatus(new Set()); };
  const setSort = (key) => {
    setSortBy(s => s.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir:'desc' });
  };

  const onSave = (item) => {
    setItems(arr => {
      const i = arr.findIndex(x => x.id === item.id);
      if (i >= 0){ const next = arr.slice(); next[i] = item; return next; }
      return [{...item, id: 'p' + Date.now()}, ...arr];
    });
    setDrawer(null);
    setToast({ msg: drawer.mode === 'new' ? 'Project Created' : 'Project Saved' });
  };

  const onDelete = (ids) => {
    const removed = items.filter(p => ids.includes(p.id));
    setItems(arr => arr.filter(p => !ids.includes(p.id)));
    setSelected(new Set());
    setConfirm(null);
    setDrawer(null);
    setToast({
      msg: ids.length > 1 ? `${ids.length} Projects Deleted` : `Deleted "${removed[0].title}"`,
      undo: () => { setItems(arr => [...removed, ...arr]); setToast(null); },
    });
  };

  const onDuplicate = (item) => {
    const copy = { ...item, id: 'p' + Date.now(), title: item.title + ' (Copy)', status:'Draft', featured:false, updated:'Today' };
    setItems(arr => [copy, ...arr]);
    setToast({ msg: 'Duplicated to draft' });
  };

  const onToggleFeature = (id) => {
    setItems(arr => arr.map(p => p.id === id ? {...p, featured: !p.featured} : p));
  };

  return (
    <>
      <header className="admin-bar">
        <div className="inner">
          <div className="brand">
            <div className="logo">V01</div>
            <div className="scope">Studio Console</div>
          </div>
          <div className="crumbs">
            <a href="index.html">Site</a>
            <span>/</span>
            <span>Admin</span>
            <span>/</span>
            <span style={{color:'var(--fg)'}}>Projects</span>
          </div>
          <div className="right">
            <div className="live"><div className="dot"></div>Live</div>
            <div className="user"><div className="av"></div>M. Voss</div>
          </div>
        </div>
      </header>

      <div className="shell">
        <aside className="side">
          <h6>Manage</h6>
          <nav>
            <a className="active" href="#"><span>Projects</span><span className="count">{stats.total}</span></a>
            <a href="#"><span>Case Studies</span><span className="count">07</span></a>
            <a href="#"><span>Clients</span><span className="count">14</span></a>
            <a href="#"><span>People</span><span className="count">42</span></a>
            <a href="#"><span>Open Roles</span><span className="count">09</span></a>
          </nav>
          <h6>Content</h6>
          <nav>
            <a href="#"><span>Pages</span><span className="count">12</span></a>
            <a href="#"><span>Press</span><span className="count">06</span></a>
            <a href="#"><span>Journal</span><span className="count">28</span></a>
            <a href="#"><span>Media Library</span><span className="count">412</span></a>
          </nav>
          <h6>Settings</h6>
          <nav>
            <a href="#"><span>Site</span></a>
            <a href="#"><span>Team Access</span></a>
            <a href="#"><span>Integrations</span></a>
          </nav>
        </aside>

        <main className="main">
          <div className="pg-head">
            <div>
              <h1>Projects</h1>
              <div className="meta"><b>{filtered.length}</b> of {items.length} · last sync 2 minutes ago</div>
            </div>
            <div className="actions">
              <button className="btn-sm">Import CSV<span style={{color:'var(--fg-mute)'}}>↑</span></button>
              <button className="btn-sm">Export</button>
              <button className="btn-sm primary" onClick={() => setDrawer({ mode:'new', item: blankProject() })}>
                + New Project
              </button>
            </div>
          </div>

          <div className="stat-row">
            <div className="stat-cell"><div className="num">{stats.total}</div><div className="lbl">Total Projects</div><div className="delta">+3 this quarter</div></div>
            <div className="stat-cell"><div className="num">{stats.published}</div><div className="lbl">Published</div><div className="delta">+1 this week</div></div>
            <div className="stat-cell"><div className="num">{stats.drafts}</div><div className="lbl">In Draft</div><div className="delta down">2 awaiting review</div></div>
            <div className="stat-cell"><div className="num">{stats.featured}</div><div className="lbl">Featured On Site</div><div className="delta">Hero + grid</div></div>
            <div className="stat-cell"><div className="num">{stats.shots.toLocaleString()}</div><div className="lbl">Shots Delivered</div><div className="delta">All-time</div></div>
          </div>

          <div className="toolbar">
            <div className="search">
              {Icon.search}
              <input type="text" placeholder="Search projects, clients, tags…" value={query} onChange={e => setQuery(e.target.value)} />
            </div>
            <div className="filter-wrap">
              <button className={'filter-btn ' + (filterCat.size ? 'on':'')} onClick={(e) => { e.stopPropagation(); setShowFilterCat(s => !s); setShowFilterStatus(false); }}>
                {Icon.filter}<span>Category {filterCat.size ? `· ${filterCat.size}` : ''}</span>
              </button>
              {showFilterCat && (
                <div className="pop" onClick={e => e.stopPropagation()}>
                  <div className="head">Filter by Category</div>
                  {CATEGORIES.map(c => (
                    <div key={c} className={'opt ' + (filterCat.has(c) ? 'on':'')} onClick={() => toggleFilter(filterCat, c, setFilterCat)}>
                      <span>{c}</span><span className="ck">✓</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="filter-wrap">
              <button className={'filter-btn ' + (filterStatus.size ? 'on':'')} onClick={(e) => { e.stopPropagation(); setShowFilterStatus(s => !s); setShowFilterCat(false); }}>
                {Icon.filter}<span>Status {filterStatus.size ? `· ${filterStatus.size}` : ''}</span>
              </button>
              {showFilterStatus && (
                <div className="pop" onClick={e => e.stopPropagation()}>
                  <div className="head">Filter by Status</div>
                  {STATUSES.map(s => (
                    <div key={s} className={'opt ' + (filterStatus.has(s) ? 'on':'')} onClick={() => toggleFilter(filterStatus, s, setFilterStatus)}>
                      <span>{s}</span><span className="ck">✓</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <button className="filter-btn" onClick={clearFilters} disabled={!query && !filterCat.size && !filterStatus.size} style={{opacity: (!query && !filterCat.size && !filterStatus.size) ? 0.4 : 1}}>Reset</button>
            <div className="view-toggle">
              <button className={view === 'list' ? 'on':''} onClick={() => setView('list')} aria-label="List view">{Icon.list}</button>
              <button className={view === 'grid' ? 'on':''} onClick={() => setView('grid')} aria-label="Grid view">{Icon.grid}</button>
            </div>
          </div>

          {(filterCat.size > 0 || filterStatus.size > 0 || query) && (
            <div className="chips">
              {query && <div className="chip"><span>Search: <b>{query}</b></span><span className="x" onClick={() => setQuery('')}>×</span></div>}
              {[...filterCat].map(c => <div key={c} className="chip"><span>Cat: <b>{c}</b></span><span className="x" onClick={() => toggleFilter(filterCat, c, setFilterCat)}>×</span></div>)}
              {[...filterStatus].map(s => <div key={s} className="chip"><span>Status: <b>{s}</b></span><span className="x" onClick={() => toggleFilter(filterStatus, s, setFilterStatus)}>×</span></div>)}
              <div className="chip clear" onClick={clearFilters}>Clear all</div>
            </div>
          )}

          {filtered.length === 0 ? (
            <div className="empty">
              <h3>No projects match.</h3>
              <p>Try clearing filters or change the search.</p>
              <button className="btn-sm" onClick={clearFilters}>Clear filters</button>
            </div>
          ) : view === 'list' ? (
            <ProjectTable
              items={pageItems}
              selected={selected}
              onToggleSelect={toggleSelect}
              onToggleAll={toggleSelectAll}
              onEdit={item => setDrawer({ mode:'edit', item })}
              onDelete={item => setConfirm({ ids:[item.id] })}
              onDuplicate={onDuplicate}
              onToggleFeature={onToggleFeature}
              sortBy={sortBy}
              setSort={setSort}
              allChecked={pageItems.length > 0 && pageItems.every(p => selected.has(p.id))}
            />
          ) : (
            <ProjectCards
              items={pageItems}
              onEdit={item => setDrawer({ mode:'edit', item })}
              onDelete={item => setConfirm({ ids:[item.id] })}
              onDuplicate={onDuplicate}
              onToggleFeature={onToggleFeature}
            />
          )}

          {filtered.length > 0 && (
            <div className="pag">
              <div className="info">Showing <b style={{color:'var(--fg)'}}>{(page-1)*PER_PAGE + 1}</b>–<b style={{color:'var(--fg)'}}>{Math.min(page*PER_PAGE, filtered.length)}</b> of {filtered.length}</div>
              <div className="nav">
                <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page === 1}>‹</button>
                {Array.from({length: totalPages}, (_, i) => (
                  <button key={i} className={page === i+1 ? 'on':''} onClick={() => setPage(i+1)}>{i+1}</button>
                ))}
                <button onClick={() => setPage(p => Math.min(totalPages, p+1))} disabled={page === totalPages}>›</button>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* bulk actions */}
      <div className={'bulk-bar ' + (selected.size > 0 ? 'show':'')}>
        <div className="count"><b>{selected.size}</b> selected</div>
        <div className="sep"></div>
        <button onClick={() => {
          const ids = [...selected];
          setItems(arr => arr.map(p => ids.includes(p.id) ? {...p, status:'Published'} : p));
          setSelected(new Set());
          setToast({ msg: `${ids.length} Published` });
        }}>Publish</button>
        <button onClick={() => {
          const ids = [...selected];
          setItems(arr => arr.map(p => ids.includes(p.id) ? {...p, status:'Archived', featured:false} : p));
          setSelected(new Set());
          setToast({ msg: `${ids.length} Archived` });
        }}>Archive</button>
        <button className="danger" onClick={() => setConfirm({ ids:[...selected] })}>Delete</button>
        <div className="sep"></div>
        <button onClick={() => setSelected(new Set())}>Clear</button>
      </div>

      {/* drawer */}
      <div className={'drawer-mask ' + (drawer ? 'open':'')} onClick={() => setDrawer(null)}></div>
      <div className={'drawer ' + (drawer ? 'open':'')}>
        {drawer && (
          <ProjectDrawer
            key={drawer.item.id || 'new'}
            mode={drawer.mode}
            item={drawer.item}
            onSave={onSave}
            onClose={() => setDrawer(null)}
            onDelete={() => setConfirm({ ids:[drawer.item.id] })}
            onDuplicate={() => { onDuplicate(drawer.item); setDrawer(null); }}
          />
        )}
      </div>

      {/* confirm modal */}
      <div className={'modal-mask ' + (confirm ? 'open':'')} onClick={() => setConfirm(null)}>
        <div className="modal" onClick={e => e.stopPropagation()}>
          {confirm && (() => {
            const targets = items.filter(p => confirm.ids.includes(p.id));
            const single = targets.length === 1;
            return (
              <>
                <h3>{single ? 'Delete project?' : `Delete ${targets.length} projects?`}</h3>
                <p>
                  {single ? <>You're about to delete <b>"{targets[0].title}"</b>. This will remove it from the public site immediately.</> : <>You're about to delete <b>{targets.length}</b> projects. They'll be removed from the public site immediately.</>}
                  {' '}You can undo this for the next few seconds.
                </p>
                <div className="actions">
                  <button className="btn-sm" onClick={() => setConfirm(null)}>Cancel</button>
                  <button className="btn-sm" onClick={() => onDelete(confirm.ids)} style={{borderColor:'#e08a76',color:'#e08a76'}}>Delete</button>
                </div>
              </>
            );
          })()}
        </div>
      </div>

      {/* toast */}
      <div className={'toast ' + (toast ? 'show':'')}>
        {toast && <>
          <span>{toast.msg}</span>
          {toast.undo && <button className="undo" onClick={toast.undo}>Undo</button>}
        </>}
      </div>
    </>
  );
}

// ---------- table view ----------
function ProjectTable({ items, selected, onToggleSelect, onToggleAll, onEdit, onDelete, onDuplicate, onToggleFeature, sortBy, setSort, allChecked }){
  const Sh = ({ k, label }) => (
    <th className={sortBy.key === k ? 'sorted':''} onClick={() => setSort(k)}>
      {label}<span className="so">{sortBy.key === k ? (sortBy.dir === 'asc' ? '↑' : '↓') : '↕'}</span>
    </th>
  );
  return (
    <table className="tbl">
      <thead>
        <tr>
          <th className="checkcol">
            <div className={'check ' + (allChecked ? 'on':'')} onClick={onToggleAll}>{Icon.check}</div>
          </th>
          <Sh k="title"    label="Project" />
          <Sh k="category" label="Category" />
          <Sh k="client"   label="Client" />
          <Sh k="year"     label="Year" />
          <Sh k="shots"    label="Shots" />
          <Sh k="status"   label="Status" />
          <Sh k="updated"  label="Updated" />
          <th style={{textAlign:'right'}}>Actions</th>
        </tr>
      </thead>
      <tbody>
        {items.map(p => (
          <tr key={p.id} className={selected.has(p.id) ? 'selected':''}>
            <td className="checkcol">
              <div className={'check ' + (selected.has(p.id) ? 'on':'')} onClick={() => onToggleSelect(p.id)}>{Icon.check}</div>
            </td>
            <td>
              <div className="title-cell">
                <div className={'thumb ' + (p.featured ? 'featured':'')}></div>
                <div className="t">
                  <b>{p.title}</b>
                  <span>{p.runtime} · {p.director}</span>
                </div>
              </div>
            </td>
            <td><span className="cat-pill">{p.category}</span></td>
            <td>{p.client}</td>
            <td>{p.year}</td>
            <td>{p.shots}</td>
            <td><span className={'pill ' + p.status.toLowerCase()}>{p.status}</span></td>
            <td style={{color:'var(--fg-dim)'}}>{p.updated}</td>
            <td>
              <div className="row-actions">
                <button className="icon-btn" title={p.featured ? 'Unfeature':'Feature'} onClick={() => onToggleFeature(p.id)} style={p.featured ? {borderColor:'var(--fg)',color:'var(--fg)'} : {}}>{Icon.star}</button>
                <button className="icon-btn" title="View" onClick={() => onEdit(p)}>{Icon.eye}</button>
                <button className="icon-btn" title="Edit" onClick={() => onEdit(p)}>{Icon.pencil}</button>
                <button className="icon-btn" title="Duplicate" onClick={() => onDuplicate(p)}>{Icon.copy}</button>
                <button className="icon-btn danger" title="Delete" onClick={() => onDelete(p)}>{Icon.trash}</button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// ---------- card view ----------
function ProjectCards({ items, onEdit, onDelete, onDuplicate, onToggleFeature }){
  return (
    <div className="card-grid">
      {items.map(p => (
        <div key={p.id} className="pcard">
          <div className="ph">
            <div className="lbl">[ {p.title.toUpperCase()} ]</div>
            <div className="pin">
              {p.featured && <span className="pill" style={{color:'var(--fg)'}}>★ Featured</span>}
              <span className="pill" style={{
                color: p.status === 'Published' ? '#5ed681' : p.status === 'Draft' ? '#e1c876' : p.status === 'Scheduled' ? '#76c4e1' : '#888'
              }}>{p.status}</span>
            </div>
          </div>
          <div className="body">
            <div className="row1">
              <h3>{p.title}</h3>
              <span className="yr">{p.year}</span>
            </div>
            <div className="meta">{p.category} · {p.client}</div>
            <div className="meta" style={{color:'var(--fg-mute)'}}>{p.runtime} · {p.shots} shots · {p.director}</div>
          </div>
          <div className="footer">
            <div className="row-actions" style={{gap:6}}>
              <button className="icon-btn" onClick={() => onToggleFeature(p.id)} style={p.featured ? {borderColor:'var(--fg)',color:'var(--fg)'} : {}}>{Icon.star}</button>
              <button className="icon-btn" onClick={() => onDuplicate(p)}>{Icon.copy}</button>
              <button className="icon-btn danger" onClick={() => onDelete(p)}>{Icon.trash}</button>
            </div>
            <button className="filter-btn" style={{padding:'7px 12px',fontSize:'10px'}} onClick={() => onEdit(p)}>Edit</button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------- drawer (edit/new) ----------
function blankProject(){
  return { id:null, title:'', client:'', category:'Brand Film', year: new Date().getFullYear(), runtime:'', status:'Draft', featured:false, director: DIRECTORS[0], vfxSup: SUPES[0], shots:0, updated:'Today', tags:[], summary:'' };
}

function ProjectDrawer({ mode, item, onSave, onClose, onDelete, onDuplicate }){
  const [draft, setDraft] = useState(item);
  const [tab, setTab]     = useState('details');
  const [tagInput, setTagInput] = useState('');
  const set = (k, v) => setDraft(d => ({...d, [k]: v}));
  const valid = draft.title.trim() && draft.client.trim();

  const addTag = () => {
    const t = tagInput.trim().toLowerCase();
    if (t && !draft.tags.includes(t)) set('tags', [...draft.tags, t]);
    setTagInput('');
  };

  return (
    <>
      <div className="drawer-head">
        <div>
          <div className="sub">{mode === 'new' ? 'New Project' : 'Editing Project'}</div>
          <h2>{draft.title || 'Untitled Project'}</h2>
        </div>
        <button className="close" onClick={onClose} aria-label="Close drawer">{Icon.close}</button>
      </div>

      <div className="dtabs" style={{padding:'0 28px'}}>
        <button className={tab === 'details' ? 'on':''} onClick={() => setTab('details')}>Details</button>
        <button className={tab === 'media'   ? 'on':''} onClick={() => setTab('media')}>Media</button>
        <button className={tab === 'credits' ? 'on':''} onClick={() => setTab('credits')}>Credits</button>
        <button className={tab === 'publish' ? 'on':''} onClick={() => setTab('publish')}>Publish</button>
      </div>

      <div className="drawer-body">
        {tab === 'details' && (
          <>
            <div className="field">
              <label>Title<span className="req">*</span></label>
              <input type="text" value={draft.title} onChange={e => set('title', e.target.value)} placeholder="e.g. Echoes of Tomorrow" autoFocus />
            </div>
            <div className="field">
              <label>Client<span className="req">*</span></label>
              <input type="text" value={draft.client} onChange={e => set('client', e.target.value)} placeholder="e.g. Atlas Pictures" />
            </div>
            <div className="field">
              <label>Category</label>
              <div className="seg">
                {CATEGORIES.map(c => <button key={c} className={draft.category === c ? 'on':''} onClick={() => set('category', c)}>{c}</button>)}
              </div>
            </div>
            <div className="field">
              <div className="row3">
                <div>
                  <label>Year</label>
                  <input type="number" value={draft.year} onChange={e => set('year', +e.target.value)} />
                </div>
                <div>
                  <label>Runtime</label>
                  <input type="text" value={draft.runtime} onChange={e => set('runtime', e.target.value)} placeholder="04:32" />
                </div>
                <div>
                  <label>Shots</label>
                  <input type="number" value={draft.shots} onChange={e => set('shots', +e.target.value)} />
                </div>
              </div>
            </div>
            <div className="field">
              <label>Summary <span className="hint">used on case study and grid hover</span></label>
              <textarea value={draft.summary} onChange={e => set('summary', e.target.value)} placeholder="Two sentences. The hook and the texture." />
            </div>
            <div className="field">
              <label>Tags</label>
              <div className="tag-input" onClick={(e) => e.currentTarget.querySelector('input').focus()}>
                {draft.tags.map(t => (
                  <span key={t} className="tg">{t}<span className="x" onClick={() => set('tags', draft.tags.filter(x => x !== t))}>×</span></span>
                ))}
                <input type="text" value={tagInput}
                  onChange={e => setTagInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addTag(); } else if (e.key === 'Backspace' && !tagInput && draft.tags.length) set('tags', draft.tags.slice(0,-1)); }}
                  placeholder={draft.tags.length ? '' : 'press enter to add'} />
              </div>
            </div>
          </>
        )}

        {tab === 'media' && (
          <>
            <div className="field">
              <label>Hero Frame <span className="hint">16:9 · 4K source</span></label>
              <div className="upload">
                <div className="ph-mini">[ DROP HERO FRAME ]</div>
                <div className="text">Click to upload or drag in · PNG, JPG, MP4</div>
              </div>
            </div>
            <div className="field">
              <label>Stills Gallery <span className="hint">up to 12</span></label>
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
                {[1,2,3,4,5,6].map(i => (
                  <div key={i} style={{aspectRatio:'4/3',background:'repeating-linear-gradient(135deg,rgba(255,255,255,0.02) 0 8px,rgba(255,255,255,0.05) 8px 16px),#171819',border:'1px solid var(--line-2)',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--mono)',fontSize:9,color:'var(--fg-mute)',letterSpacing:'.18em'}}>
                    {i <= 3 ? `STILL ${String(i).padStart(2,'0')}` : '+ ADD'}
                  </div>
                ))}
              </div>
            </div>
            <div className="field">
              <label>Film File <span className="hint">streaming master</span></label>
              <input type="text" defaultValue={draft.id ? `v01-${draft.id}-master-4k.mp4` : ''} placeholder="upload to attach" />
            </div>
          </>
        )}

        {tab === 'credits' && (
          <>
            <div className="field">
              <label>Director</label>
              <select value={draft.director} onChange={e => set('director', e.target.value)}>
                {DIRECTORS.map(d => <option key={d}>{d}</option>)}
              </select>
            </div>
            <div className="field">
              <label>VFX Supervisor</label>
              <select value={draft.vfxSup} onChange={e => set('vfxSup', e.target.value)}>
                {SUPES.map(d => <option key={d}>{d}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Producer</label>
              <input type="text" placeholder="Elliot Pace" />
            </div>
            <div className="field">
              <label>DOP</label>
              <input type="text" placeholder="Director of Photography" />
            </div>
            <div className="field">
              <label>Editor</label>
              <input type="text" placeholder="Lead Editor" />
            </div>
            <div className="field">
              <label>Sound Design</label>
              <input type="text" placeholder="Sound design lead" />
            </div>
          </>
        )}

        {tab === 'publish' && (
          <>
            <div className="field">
              <label>Status</label>
              <div className="seg">
                {STATUSES.map(s => <button key={s} className={draft.status === s ? 'on':''} onClick={() => set('status', s)}>{s}</button>)}
              </div>
            </div>
            <div className="field">
              <label>Visibility</label>
              <div className="toggle-row">
                <div className="meta">Featured on Home<span>Pinned to hero + selected work grid</span></div>
                <div className={'toggle ' + (draft.featured ? 'on':'')} onClick={() => set('featured', !draft.featured)}></div>
              </div>
              <div className="toggle-row">
                <div className="meta">Listed in Work archive<span>Shown in /work browse view</span></div>
                <div className="toggle on"></div>
              </div>
              <div className="toggle-row">
                <div className="meta">Allow press download<span>Generate stills + sizzle for press kit</span></div>
                <div className="toggle"></div>
              </div>
              <div className="toggle-row">
                <div className="meta">Show case study<span>Renders /case-study/{draft.id || 'new'}</span></div>
                <div className="toggle on"></div>
              </div>
            </div>
            <div className="field">
              <label>Schedule</label>
              <div className="row">
                <input type="text" placeholder="Apr 30, 2026" />
                <input type="text" placeholder="14:00 PT" />
              </div>
            </div>

            {mode === 'edit' && (
              <div className="danger-zone">
                <h4>Danger Zone</h4>
                <p>Permanently remove this project from the site. This cannot be undone after the toast clears.</p>
                <button onClick={onDelete}>Delete Project</button>
              </div>
            )}
          </>
        )}
      </div>

      <div className="drawer-foot">
        <div className="left">
          {mode === 'edit' && <button className="btn-sm" onClick={onDuplicate}>Duplicate</button>}
        </div>
        <div className="right">
          <button className="btn-sm" onClick={onClose}>Cancel</button>
          <button className="btn-sm primary" disabled={!valid} style={!valid ? {opacity:0.4,cursor:'not-allowed'} : {}} onClick={() => valid && onSave(draft)}>{mode === 'new' ? 'Create' : 'Save Changes'}</button>
        </div>
      </div>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
